package com.path.approach2;

public class Important {
	public static void main(String[] args) {
		Important n1=new Important();
		System.out.println(n1.batsman);
		n1.display();
		System.out.println(Normal.bowler);
		System.out.println("Normal.display2()");
		
	}

}
