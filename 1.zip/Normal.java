package com.path.approach2;

public class Normal {
	public static void main(String[] args) {
		Normal n1=new Normal();
		System.out.println(n1.batsman);
		n1.display();
		System.out.println(Normal.bowler);
		System.out.println("Normal.display2()");
		
	}

}
