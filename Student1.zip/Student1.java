package Student1;

public class Student1 {
	private String name;
	private String address;
	private String surname;
	public int age;

}
