package com.example.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private long id;
private String itemName;
private double price;
private LocalDate manufacturingDate;
private LocalDate expiry;
public Item() {
	super();
}
public Item(long id, String itemName, double price, LocalDate manufacturingDate, LocalDate expiry) {
	super();
	this.id = id;
	this.itemName = itemName;
	this.price = price;
	this.manufacturingDate = manufacturingDate;
	this.expiry = expiry;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getItemName() {
	return itemName;
}
public void setItemName(String itemName) {
	this.itemName = itemName;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public LocalDate getManufacturingDate() {
	return manufacturingDate;
}
public void setManufacturingDate(LocalDate manufacturingDate) {
	this.manufacturingDate = manufacturingDate;
}
public LocalDate getExpiry() {
	return expiry;
}
public void setExpiry(LocalDate expiry) {
	this.expiry = expiry;
}
@Override
public String toString() {
	return "Item [id=" + id + ", itemName=" + itemName + ", price=" + price + ", manufacturingDate=" + manufacturingDate
			+ ", expiry=" + expiry + "]";
}

}
