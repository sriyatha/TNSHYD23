package com.example.controller;




import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.entity.Item;
import com.example.repository.ItemRepository;
import com.example.exception.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/item")
public class Itemcontroller   {
	

	@Autowired
	private ItemRepository repo;
	
	// get all items
	@GetMapping("/item")
	public List<Item> getAllitems(){
		return repo.findAll();
	}		
	
	// create item rest api
	@PostMapping("/item")
	public Item createEmployee(@RequestBody Item item) {
		return repo.save(item);
	}
	
	// get item by id rest api
	@GetMapping("/item/{id}")
	public ResponseEntity<Item> getEmployeeById(@PathVariable Long id) {
		Item item = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Item not exist with id :" + id));
		return ResponseEntity.ok(item);
	}
	
	// update item rest api
	
	@PutMapping("/item/{id}")
	public ResponseEntity<Item> updateItem(@PathVariable Long id, @RequestBody Item itemDetails){
	Item item = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Item not exist with id :" + id));
		
		item.setItemName(itemDetails.getItemName());
		item.setPrice(itemDetails.getPrice());
		item.setManufacturingDate(itemDetails.getManufacturingDate());
		item.setExpiry(itemDetails.getExpiry());
		Item updatedItem = repo.save(item);
		return ResponseEntity.ok(updatedItem);
	}
	
	// delete item rest api
	@DeleteMapping("/item/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteItem(@PathVariable Long id){
		Item item = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Item not exist with id :" + id));
		
		repo.delete(item);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}
