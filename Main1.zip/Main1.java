package Student2;

import Student1.Student1;

public class Main1 {
	public static void main(String[] args) {
		Student1 s1=new Student1();
		s1.age=20;
		System.out.println(s1.age);
	}

}
