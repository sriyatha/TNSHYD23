package Student4;

public class Student3 {
	
		
		public static void main(String[] args) {
			Student3 s3= new Student3();
			s3.setAge(40);
			System.out.println(s3.getAge());
			
			
			s3.setName("Dolly");
			System.out.println(s3.getName());
			
			
		}

	}



