package Student4;


public class Main2 {
	
		
		public static void main(String[] args) {
			Student3 s3= new Student3();
			s3.setAge(40);
			System.out.println(s3.getAge());
			s3.setName("dolly");
			System.out.println(s3.getName());
			
			
		}

	}



