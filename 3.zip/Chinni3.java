package protect2;
import protect.Chinni1;
class Chinni3 extends Chinni1 {
public static void main(String[] args) {
	Chinni3 a= new Chinni3();
	a.display();
}
}
