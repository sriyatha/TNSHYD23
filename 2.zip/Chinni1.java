package protect;

public class Chinni1 {
	protected void display() {
		
		System.out.println("this is sriyatha");
	}
	}

